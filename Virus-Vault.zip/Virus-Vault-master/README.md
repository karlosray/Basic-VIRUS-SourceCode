# Virus-VaultBe 
Careful what you are trying to use code for and use source code on your own risk. Resuts can be loss of data, hardware or both. 
##If you are using source code then you will be responsible for your or loss to any victim.

Malacius software source code collection for study. this project contain a number of Source code of viruses, trojans, scripts for resorch purpose .
For securiy ressons they are kept in text fomate.

##How to use
- Change extension of file in BAT section or suffix _BAT with .bat
- Change file extenntsion of files in VBS section oe sufffix -VBS with .vbs
- Change file extension of files ith suffix _EXE with .exe
- Click on file to execute

##When to use
- When you know exectly what you are doing and ready to accept consequences. 
